using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using LHPet.Models;

namespace LHPet.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        // Instancias do tipo cliente e atribui os clientes
        Cliente cliente1 = new Cliente(01, "Gabriel A.", "123.456.789-01", "gabriel1@gmail.com", "Bally");
        Cliente cliente2 = new Cliente(02, "Gabriel B.", "123.456.789-02", "gabriel2@gmail.com", "Estrela");
        Cliente cliente3 = new Cliente(03, "Gabriel C.", "123.456.789-03", "gabriel3@gmail.com", "Dobby");
        Cliente cliente4 = new Cliente(04, "Gabriel D.", "123.456.789-04", "gabriel4@gmail.com", "Slick");
        Cliente cliente5 = new Cliente(05, "Gabriel E.", "123.456.789-05", "gabriel5@gmail.com", "Madruga");

        // Lista de clientes
        List<Cliente> listaClientes = new List<Cliente>();
        listaClientes.Add(cliente1);
        listaClientes.Add(cliente2);
        listaClientes.Add(cliente3);
        listaClientes.Add(cliente4);
        listaClientes.Add(cliente5);

        ViewBag.listaClientes = listaClientes;

        // Instancias do tipo fornecedor e atribui os fornecedores
        Fornecedor fornecedor1 = new Fornecedor(01, "C# PET S/A", "12.345.678/0000-01", "emailforn1@corp.org");
        Fornecedor fornecedor2 = new Fornecedor(02, "Ctrl Alt Dog", "12.345.678/0000-02", "emailforn2@corp.org");
        Fornecedor fornecedor3 = new Fornecedor(03, "Bootspet Inc", "12.345.678/0000-03", "emailforn3@corp.org");
        Fornecedor fornecedor4 = new Fornecedor(04, "Tiktok Dogs", "12.345.678/0000-04", "emailforn4@corp.org");
        Fornecedor fornecedor5 = new Fornecedor(05, "Bifinho Forever", "12.345.678/0000-05", "emailforn5@corp.org");

        // Lista de fornecedores
        List<Fornecedor> listaFornecedores = new List<Fornecedor>();
        listaFornecedores.Add(fornecedor1);
        listaFornecedores.Add(fornecedor2);
        listaFornecedores.Add(fornecedor3);
        listaFornecedores.Add(fornecedor4);
        listaFornecedores.Add(fornecedor5);

        ViewBag.listaFornecedores = listaFornecedores;


        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
